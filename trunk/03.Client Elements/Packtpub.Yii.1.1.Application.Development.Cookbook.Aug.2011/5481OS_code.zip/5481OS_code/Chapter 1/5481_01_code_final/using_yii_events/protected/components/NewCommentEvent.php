<?php
class NewCommentEvent extends CModelEvent {
	public $comment;
	public $post;
}
