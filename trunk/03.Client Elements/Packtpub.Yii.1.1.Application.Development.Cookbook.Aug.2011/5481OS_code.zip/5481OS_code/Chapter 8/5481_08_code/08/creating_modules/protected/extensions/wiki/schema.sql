CREATE TABLE `wiki` (
  `id` varchar(255) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY  (`id`)
)
