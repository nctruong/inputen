<h2>
	<?php echo CHtml::encode($model->id)?>
	[<?php echo CHtml::link('edit', array('edit', 'id' => $model->id))?>]
</h2>
<?php echo $model->html ?>