<?php
return array(
	array(
		'id' => 1,
		'title' => 'post1',
		'text' => 'post1',
		'is_deleted' => 0,
	),
	array(
		'id' => 2,
		'title' => 'post2',
		'text' => 'post2',
		'is_deleted' => 1,
	),
	array(
		'id' => 3,
		'title' => 'post3',
		'text' => 'post3',
		'is_deleted' => 0,
	),
	array(
		'id' => 4,
		'title' => 'post4',
		'text' => 'post4',
		'is_deleted' => 1,
	),
	array(
		'id' => 5,
		'title' => 'post5',
		'text' => 'post5',
		'is_deleted' => 0,
	),
);

