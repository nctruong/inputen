<h2><?php echo CHtml::link('Snippets', array('index'))?> → Add snippet</h2>
<?php $this->renderPartial('_form', array('model' => $model))?>