<?php $this->widget('ECheckAllWidget')?>

<?php echo CHtml::checkBox('test1', true)?>
<?php echo CHtml::checkBox('test2', false)?>
<?php echo CHtml::checkBox('test3', true)?>
<?php echo CHtml::checkBox('test4', false)?>
<?php echo CHtml::checkBox('test5', true)?>
<?php echo CHtml::checkBox('test6', true)?>