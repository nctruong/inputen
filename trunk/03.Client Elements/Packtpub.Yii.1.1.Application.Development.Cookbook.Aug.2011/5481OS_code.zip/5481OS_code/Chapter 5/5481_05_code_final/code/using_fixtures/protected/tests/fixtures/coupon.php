<?php
return array(
	array(
		'id' => 'free_book',
		'description' => 'Choose one book for free!',
	),
	array(
		'id' => 'merry_christmas',
		'description' => '5% Christmas discount!',
	),
	array(
		'id' => 'discount_for_me',
		'description' => '5% discount special for you!',
	),
);