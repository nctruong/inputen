<?php
class MaintenanceController extends CController
{
	public function actionIndex()
	{
		$this->renderPartial("index");
	}
}
