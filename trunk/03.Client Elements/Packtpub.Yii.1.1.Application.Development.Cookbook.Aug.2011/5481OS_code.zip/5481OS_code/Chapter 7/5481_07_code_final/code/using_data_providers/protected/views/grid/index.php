<?php $this->widget('zii.widgets.grid.CGridView', array(
	'dataProvider' => $dataProvider,
))?>
