<div class="facebook-events" data-url="<?php echo $url?>">
	<h2><?php echo $keyword?> events</h2>
	<div class="data">
		<?php echo CHtml::image($loadingImageUrl)?>
	</div>
</div>